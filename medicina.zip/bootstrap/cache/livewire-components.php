<?php return array (
  'agenda-consulta.create-consulta' => 'App\\Http\\Livewire\\AgendaConsulta\\CreateConsulta',
  'home.agendar-cita' => 'App\\Http\\Livewire\\Home\\AgendarCita',
  'pais.pais-create' => 'App\\Http\\Livewire\\Pais\\PaisCreate',
  'pais.pais-index' => 'App\\Http\\Livewire\\Pais\\PaisIndex',
  'persona.create-persona' => 'App\\Http\\Livewire\\Persona\\CreatePersona',
  'persona.editar-persona' => 'App\\Http\\Livewire\\Persona\\EditarPersona',
);