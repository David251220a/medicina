<nav id="sidebar">
    <div class="shadow-bottom"></div>
    <ul class="list-unstyled menu-categories" id="accordionExample">

        <li class="menu">
            <a href="<?php echo e(route('home')); ?>" <?php echo e((Route::currentRouteName() == 'home' ? 'data-active=true' : '')); ?>  aria-expanded="false" class="dropdown-toggle">
                <div class="">
                    <i class="fa-solid fa-house mr-3"></i>
                    <span>Inicio</span>
                </div>
            </a>
        </li>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('persona.index')): ?>
            <li class="menu">
                <a href="<?php echo e(route('persona.index')); ?>" <?php echo e((substr(Route::currentRouteName() , 0 , strpos(Route::currentRouteName(), '.')) == 'persona' ? 'data-active=true' : '')); ?>

                    aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i class="fas fa-user mr-3"></i>
                        <span>Persona</span>
                    </div>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('paciente.index')): ?>
            <li class="menu">
                <a href="<?php echo e(route('paciente.index')); ?>" <?php echo e((substr(Route::currentRouteName() , 0 , strpos(Route::currentRouteName(), '.')) == 'paciente' ? 'data-active=true' : '')); ?>

                    aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i class="fas fa-user-injured mr-3"></i>
                        <span>Paciente</span>
                    </div>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor.index')): ?>
            <li class="menu">
                <a href="<?php echo e(route('doctor.index')); ?>" <?php echo e((substr(Route::currentRouteName() , 0 , strpos(Route::currentRouteName(), '.')) == 'doctor' ? 'data-active=true' : '')); ?>

                    aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i class="fas fa-user-md mr-3"></i>
                        <span>Doctor</span>
                    </div>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('especialidad.index')): ?>
            <li class="menu">
                <a href="<?php echo e(route('especialidad.index')); ?>" <?php echo e((substr(Route::currentRouteName() , 0 , strpos(Route::currentRouteName(), '.')) == 'especialidad' ? 'data-active=true' : '')); ?>

                    aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i class="fas fa-star-of-life mr-3"></i>
                        <span>Especialidad</span>
                    </div>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('agenda_consulta.index')): ?>
            <li class="menu">
                <a href="<?php echo e(route('agenda_consulta.index')); ?>" <?php echo e((substr(Route::currentRouteName() , 0 , strpos(Route::currentRouteName(), '.')) == 'agenda_consulta' ? 'data-active=true' : '')); ?>

                    aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i class="fas fa-calendar-times mr-3"></i>
                        <span>Agenda Consulta</span>
                    </div>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('consulta.index')): ?>
            <li class="menu">
                <a href="<?php echo e(route('consulta.index')); ?>" <?php echo e((substr(Route::currentRouteName() , 0 , strpos(Route::currentRouteName(), '.')) == 'consulta' ? 'data-active=true' : '')); ?>

                    aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i class="fas fa-question mr-3"></i>
                        <span>Consulta General</span>
                    </div>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor_consulta.index')): ?>
            <li class="menu">
                <a href="<?php echo e(route('doctor_consulta.index')); ?>" <?php echo e((substr(Route::currentRouteName() , 0 , strpos(Route::currentRouteName(), '.')) == 'doctor_consulta' ? 'data-active=true' : '')); ?>

                    aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i class="fas fa-stethoscope mr-3"></i>
                        <span>Doctor M.</span>
                    </div>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.index')): ?>
            <li class="menu">
                <a href="<?php echo e(route('user.index')); ?>" <?php echo e((substr(Route::currentRouteName() , 0 , strpos(Route::currentRouteName(), '.')) == 'user' ? 'data-active=true' : '')); ?>

                    aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i class="fas fa-user-tie mr-3"></i>
                        <span>Usuario</span>
                    </div>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.index')): ?>
            <li class="menu">
                <a href="<?php echo e(route('role.index')); ?>" <?php echo e((substr(Route::currentRouteName() , 0 , strpos(Route::currentRouteName(), '.')) == 'role' ? 'data-active=true' : '')); ?>

                    aria-expanded="false" class="dropdown-toggle">
                    <div class="">
                        <i class="fas fa-users mr-3"></i>
                        <span>Grupo Usuario</span>
                    </div>
                </a>
            </li>
        <?php endif; ?>

    </ul>
    <!-- <div class="shadow-bottom"></div> -->

</nav>
<?php /**PATH C:\laragon\www\medicina\resources\views/layouts/admin/sidebar.blade.php ENDPATH**/ ?>