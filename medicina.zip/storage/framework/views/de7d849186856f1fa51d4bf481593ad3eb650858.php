<div>
    <div class="form-row">
        <div class="col-md-3 col-sm-6 mb-4">
            <label for="">Documento Paciente</label>
            <label for="" class="form-control"> <?php echo e(number_format(Auth::user()->persona->documento, 0, ".", ".")); ?></label>
        </div>

        <div class="col-md-3 col-sm-6 mb-2">
            <label for="">Nombre Paciente</label>
            <label for="" class="form-control"> <?php echo e(Auth::user()->persona->nombre); ?> <?php echo e(Auth::user()->persona->apellido); ?></label>
        </div>
    </div>

    <div class="form-row">
        <div class="col-md-3 col-sm-6 mb-2">
            <label for="">Fecha Agenda</label>
            <input wire:model.defer="fecha" type="date" class="form-control" value="<?php echo e($fecha); ?>" name="fecha_consulta">
            <?php if($error_fecha): ?>
                <span class="red">
                    <?php echo e($error_fecha); ?>

                </span>
            <?php endif; ?>
        </div>

        <div class="col-md-4 col-sm-6 mb-2">
            <label for="">Doctor</label>
            <select wire:model="turno_id" class="form-control" name="doctor_turno_id" required>
                <?php
                    $hay_doctores = 0;
                ?>
                <?php if(count($doctor) > 0): ?>
                    <?php $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->cont < $limite_atencion): ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->cont); ?> - <?php echo e($item->doctor->persona->nombre); ?> <?php echo e($item->doctor->persona->apellido); ?></option>
                            <?php
                                $hay_doctores = 1;
                            ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($hay_doctores == 0): ?>
                        <option value="" selected>No hay doctores disponible en esta fecha!</option>
                    <?php endif; ?>
                <?php else: ?>
                    <option value="" selected>No hay doctores disponible en esta fecha!</option>
                <?php endif; ?>

            </select>
        </div>
        <div class="col-md-4 col-sm-6 mb-2">
            <label for="">Detalles Doctor</label>
            <p><?php echo e($detalles_doctor); ?></p>
        </div>
        <div class="col-md-4 col-sm-6 mb-2">
            <button type="button" class="btn btn-info" onclick="doctor_disponible()">Doctor Disponible</button>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\medicina\resources\views/livewire/home/agendar-cita.blade.php ENDPATH**/ ?>