<div class="form-row">
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Pais - <button type="button" data-toggle="modal" data-target="#paismodal" style="border-radius: 15px">Crear</button></label>
        <select wire:model="pais_id" name="pais_id" class="form-control " onchange="actualizar_pais()">
            <?php $__currentLoopData = $pais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->descripcion); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Departamento - <button type="button" data-toggle="modal" data-target="#deparmodal" style="border-radius: 15px">Crear</button></label>
        <select wire:model="departamento_id" name="departamento_id" class="form-control " onchange="actualizar_departamento()">
            <?php $__currentLoopData = $departamento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->descripcion); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Ciudad - <button type="button" data-toggle="modal" data-target="#ciudadmodal" style="border-radius: 15px">Crear</button></label>
        <select wire:model="ciudad_id" name="ciudad_id" class="form-control ">
            <?php $__currentLoopData = $ciudad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->descripcion); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Barrio</label>
        <input type="text" class="form-control" id="barrio" name="barrio" placeholder="Barrio" required>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>

    <?php echo $__env->make('ui.modal.agregar_pais', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('ui.modal.agregar_departamento', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('ui.modal.agregar_ciudad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\laragon\www\medicina\resources\views/livewire/persona/create-persona.blade.php ENDPATH**/ ?>