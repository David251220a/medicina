<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="layout-px-spacing">

        <h2 class="mt-3">Editar Usuario: <?php echo e($user->name); ?></h2>
        <div class="widget-content widget-content-area">
            <form action="<?php echo e(route('user.update', $user)); ?>" method="post" onsubmit="return checkSubmit();">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-sm-12 mb-4">
                        <label for="">Documento</label>
                        <input type="text" class="form-control" name="documento" value="<?php echo e(old('documento', number_format($user->documento, 0, ".", "."))); ?>"
                        onkeyup="punto_decimal(this)" onchange="punto_decimal(this)" required>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-12 mb-4">
                        <label for="">Nombre y Apellido</label>
                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $user->name)); ?>" required>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-12 mb-4">
                        <label for="">Email</label>
                        <input type="text" class="form-control" name="email" value="<?php echo e(old('email', $user->email)); ?>" >
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-12 mb-4">
                        <label for="">Contraseña</label>
                        <input type="password" class="form-control" name="password" id="password" value="<?php echo e(old('password')); ?>" >
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-12 mb-4">
                        <label for="">Repetir Contraseña</label>
                        <input type="password" class="form-control" name="password_rep" id="password_rep" value="<?php echo e(old('password')); ?>"
                        onkeyup="verificar_pass()" >
                        <span id="msj" style="display: none"><p style="color: red">Las contraseñas no coinciden!!</p></span>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-12 mb-4">
                        <label for="">Grupo</label>
                        <select name="rol" id="rol" class="form-control">
                            <option value=""></option>
                            <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e($user->hasRole($item->id) ? 'selected' : null); ?>><?php echo e($item->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <button type="submit" id="enviar" class="btn btn-success ml-3">Editar</button>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>

    function verificar_pass()
    {
        let valorInput1 = document.getElementById('password').value;
        let valorInput2 = document.getElementById('password_rep').value;
        let enviar = document.getElementById('enviar');
        let msj = document.getElementById('msj');

        if (valorInput1 === valorInput2) {
            enviar.disabled = false;
            msj.style.display = 'none';
        } else {
            enviar.disabled = true;
            msj.style.display = 'block';
        }
    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\medicina\resources\views/usuario/edit.blade.php ENDPATH**/ ?>