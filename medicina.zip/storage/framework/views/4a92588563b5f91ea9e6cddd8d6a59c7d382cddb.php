<div class="form-row">
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Documento</label>
        <input type="text" class="form-control" id="documento" name="documento" placeholder="Documento" value="<?php echo e(old('documento')); ?>" required>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Nombre</label>
        <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre" value="<?php echo e(old('nombre')); ?>" required>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>

    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Apellido</label>
        <input type="text" class="form-control" id="apellido" name="apellido" placeholder="Apellido" value="<?php echo e(old('apellido')); ?>" required>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>

    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Sexo</label>
        <select name="sexo" id="sexo" class="form-control">
            <option value="0">SIN ESPECIFICAR</option>
            <option value="1">MASCULINO</option>
            <option value="2">FEMENINO</option>
        </select>
    </div>

</div>
<div class="form-row">
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Fecha de nacimiento</label>
        <input type="date" class="form-control" id="fecha_nacimiento" name="fecha_nacimiento" value="<?php echo e(old('fecha_nacimiento')); ?>" required>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Estado Civil</label>
        <select name="estado_civil_id" id="estado_civil_id" class="form-control">
            <?php $__currentLoopData = $estado_civil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->descripcion); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Celular</label>
        <input type="text" class="form-control" id="celular" name="celular" value="<?php echo e(old('celular')); ?>">
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Dirección</label>
        <input type="text" class="form-control" id="direccion" name="direccion" value="<?php echo e(old('direccion')); ?>" required>
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>
</div>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('persona.create-persona')->html();
} elseif ($_instance->childHasBeenRendered('fAkKLO1')) {
    $componentId = $_instance->getRenderedChildComponentId('fAkKLO1');
    $componentTag = $_instance->getRenderedChildComponentTagName('fAkKLO1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('fAkKLO1');
} else {
    $response = \Livewire\Livewire::mount('persona.create-persona');
    $html = $response->html();
    $_instance->logRenderedChild('fAkKLO1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<div class="form-row">
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Dirección Laboral</label>
        <input type="text" class="form-control" id="direccion_laboral" name="direccion_laboral" value="<?php echo e(old('direccion_laboral')); ?>">
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Telefono Laboral</label>
        <input type="text" class="form-control" id="telefono_laboral" name="telefono_laboral" value="<?php echo e(old('telefono_laboral')); ?>">
        <div class="valid-feedback">
            Looks good!
        </div>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Fallecido</label>
        <select name="fallecido" id="fallecido" class="form-control">
            <option value="0">NO</option>
            <option value="1">SI</option>
        </select>
    </div>
    <div class="col-md-3 col-sm-6 mb-4">
        <label for="">Estado</label>
        <select name="estado_id" id="estado_id" class="form-control">
            <option value="1">ACTIVO</option>
            <option value="2">INACTIVO</option>
        </select>
    </div>

    <div class="col-md-6 col-sm-6 mb-4">
        <label for="">Motivo Inactivo</label>
        <input type="text" class="form-control" id="motivo_inactivo" name="motivo_inactivo" value="<?php echo e(old('motivo_inactivo')); ?>">
    </div>
</div>
<?php /**PATH C:\laragon\www\medicina\resources\views/ui/agregar_persona.blade.php ENDPATH**/ ?>