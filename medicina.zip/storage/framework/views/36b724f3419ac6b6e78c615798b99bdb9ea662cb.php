<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('plugins/sweetalerts/sweetalert.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/components/custom-sweetalert.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/elements/search.css')); ?>" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/datatables.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/dt-global_style.css')); ?>">
    <link href="<?php echo e(asset('assets/css/elements/popover.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="layout-px-spacing">
        <div class="row" style="margin-top: 15px">
            <div class="col-lg-4 col-md-12 col-sm-12 mb-2" style="line-height: 12px">
                <p style="font-size: 23px">Doctor: <b><?php echo e($doctor->persona->nombre); ?> <?php echo e($doctor->persona->apellido); ?></b></p>

            </div>

            <div class="col-lg-4 col-md-12 col-sm-12 mb-2" style="line-height: 12px">
                <p style="font-size: 23px">Especialidad: <b><?php echo e($doctor->especialista->descripcion); ?></b></p>
            </div>

        </div>

        <div class="row">
            <div class="col-xl-4 col-lg-4 col-sm-4">
                <?php echo $__env->make('ui.busqueda', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <div class="row layout-top-spacing" id="cancel-row">

            <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                <div class="widget-content widget-content-area br-6">
                    <div class="table-responsive">
                        <table id="zero-config" class="table dt-table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Documento</th>
                                    <th>Nombre y Apellido</th>
                                    <th>Sexo</th>
                                    <th>Edad</th>
                                    <th>Celular</th>
                                    <th>Orden</th>
                                    <th>Estado</th>
                                    <th class="no-content"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align: right"><?php echo e(number_format($item->paciente->persona->documento, 0, ".", ".")); ?></td>
                                        <td><?php echo e($item->paciente->persona->nombre); ?> <?php echo e($item->paciente->persona->apellido); ?></td>
                                        <td>
                                            <?php
                                                $sexo = '';
                                                if($item->paciente->persona->sexo == 0){
                                                    $sexo = 'SIN ESPECIFICAR';
                                                }
                                                if($item->paciente->persona->sexo == 1){
                                                    $sexo = 'MASCULINO';
                                                }
                                                if($item->paciente->persona->sexo == 2){
                                                    $sexo = 'FEMENINO';
                                                }
                                            ?>
                                            <?php echo e($sexo); ?>

                                        </td>
                                        <td>
                                            <?php
                                                $año = date('Y', strtotime($item->paciente->persona->fecha_nacimiento));
                                                $mes = date('m', strtotime($item->paciente->persona->fecha_nacimiento));
                                                $dia = date('d', strtotime($item->paciente->persona->fecha_nacimiento));

                                                $edad = Carbon\Carbon::createFromDate($año,$mes,$dia)->age;
                                            ?>
                                           <?php echo e(($edad)); ?>

                                        </td>
                                        <td><?php echo e($item->paciente->persona->celular); ?></td>
                                        <td style="text-align: right"><?php echo e($item->orden); ?></td>
                                        <td id="<?php echo e($item->id); ?>"><?php echo e($item->estado_consulta->descripcion); ?></td>
                                        <td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor_consulta.atender')): ?>
                                                <a href="<?php echo e(route('doctor_consulta.atender', $item)); ?>"
                                                class="bs-popover mr-2" data-container="body" data-container="body" data-trigger="hover" data-placement="top" data-content="Atender">
                                                    <i class="fas fa-clipboard-user"></i>
                                                </a>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor_consulta.editar_estado')): ?>
                                                <a onclick="abrir_modal(<?php echo e($item->id); ?>)"
                                                class="bs-popover mr-2" data-container="body" data-container="body" data-trigger="hover" data-placement="top" data-content="Cambiar Estado">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            <?php endif; ?>

                                            <?php if($item->consulta): ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('doctor_consulta.atendido')): ?>
                                                    <a href="<?php echo e(route('doctor_consulta.atendido', $item->consulta)); ?>"
                                                    class="bs-popover mr-2" data-container="body" data-container="body" data-trigger="hover" data-placement="top" data-content="Ver Detalle">
                                                        <i class="fas fa-id-card-alt"></i>
                                                    </a>
                                                <?php endif; ?>

                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>

                </div>
            </div>

        </div>

    </div>

    <?php echo $__env->make('ui.modal.editar_estado', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/sweetalerts/custom-sweetalert.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/elements/popovers.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\medicina\resources\views/doctor_consulta/index.blade.php ENDPATH**/ ?>