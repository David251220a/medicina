<div id="edit_estado" hidden>
    <div class="Row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <label for="">Estado</label>
            <select name="estado_consulta_id" id="estado_consulta_id" class="form-control">
                <?php $__currentLoopData = $estado_consulta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->descripcion); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\medicina\resources\views/ui/modal/editar_estado.blade.php ENDPATH**/ ?>