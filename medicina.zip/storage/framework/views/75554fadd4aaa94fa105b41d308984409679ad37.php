<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('plugins/animate/animate.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/components/custom-modal.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('plugins/sweetalerts/sweetalert.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/components/custom-sweetalert.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="layout-px-spacing">
        <div class="row">
            <div class="col-12">
                <h5 class="mt-3 mb-4">Agenda Consulta - <?php echo e($especialidad->descripcion); ?></h5>
            </div>

        </div>

        <div class="col-lg-12 layout-spacing">
            <div class="widget-content widget-content-area">
                <form class="needs-validation" novalidate action="<?php echo e(route('home.agendar_cita_store', $especialidad)); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home.agendar-cita', ['especialidad' => $especialidad])->html();
} elseif ($_instance->childHasBeenRendered($especialidad->id)) {
    $componentId = $_instance->getRenderedChildComponentId($especialidad->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($especialidad->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($especialidad->id);
} else {
    $response = \Livewire\Livewire::mount('home.agendar-cita', ['especialidad' => $especialidad]);
    $html = $response->html();
    $_instance->logRenderedChild($especialidad->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <button class="btn btn-primary mt-3" type="submit">Grabar</button>

                </form>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/js/forms/bootstrap_validation/bs_validation_script.js')); ?>"></script>
    <script src="<?php echo e(asset('js/agenda_consulta/agendar.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/sweetalerts/custom-sweetalert.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\medicina\resources\views/agendar_cita.blade.php ENDPATH**/ ?>