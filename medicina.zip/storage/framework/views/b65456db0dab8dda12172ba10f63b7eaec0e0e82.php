<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="layout-px-spacing">

        <h2 class="mt-3">Editar Rol: <?php echo e($data->name); ?></h2>
        <div class="widget-content widget-content-area">
            <form action="<?php echo e(route('role.update', $data)); ?>" method="POST" onsubmit="return checkSubmit();">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 mb-4">
                        <label for="">Rol</label>
                        <input type="text" class="form-control" name="name" id="name" value="<?php echo e($data->name); ?>">
                    </div>
                </div>
                <h4 class="">Permisos</h4>
                <div class="row">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-3 col-sm-12 mb-4">
                            <label>
                                <input type="checkbox" name="permissions[]" id="permissions" class=""
                                value="<?php echo e($item['id']); ?>" <?php echo e($data->hasPermissionTo($item['id']) ? 'checked' : null); ?>>
                                <?php echo e($item->descripcion); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button type="submit" class="btn btn-success">Editar</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\medicina\resources\views/roles/edit.blade.php ENDPATH**/ ?>