<select class="form-control" id="dias">
    <option value="1">DOMINGO</option>
    <option value="2">LUNES</option>
    <option value="3">MARTES</option>
    <option value="4">MIERCOLES</option>
    <option value="5">JUEVES</option>
    <option value="6">VIERNES</option>
    <option value="7">SABADO</option>
</select>
<?php /**PATH C:\laragon\www\medicina\resources\views/ui/dias.blade.php ENDPATH**/ ?>