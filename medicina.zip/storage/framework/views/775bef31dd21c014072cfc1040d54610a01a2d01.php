<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="layout-px-spacing">

        <h2 class="mt-3">Crear Rol</h2>
        <div class="widget-content widget-content-area">
            <form action="<?php echo e(route('role.store')); ?>" method="POST" onsubmit="return checkSubmit();">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 mb-4">
                        <label for="">Rol</label>
                        <input type="text" class="form-control" name="name" id="name" value="<?php echo e(old('name')); ?>">
                    </div>
                </div>

                <button type="submit" class="btn btn-success">Guardar</button>

            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\medicina\resources\views/roles/create.blade.php ENDPATH**/ ?>