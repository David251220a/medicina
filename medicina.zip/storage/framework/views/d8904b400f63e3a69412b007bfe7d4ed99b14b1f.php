<?php $__env->startSection('styles'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/select2/select2.min.css')); ?>">
    <link href="<?php echo e(asset('assets/css/components/custom-modal.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('plugins/animate/animate.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('plugins/sweetalerts/sweetalert.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/components/custom-sweetalert.css')); ?>" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row layout-top-spacing">
        <div class="col-lg-12 layout-spacing">
            <div class="widget-content widget-content-area">
                <div class="row" style="margin-left: 3px">
                    <h3 class="mb-4">Agregar Paciente</h3>
                </div>
                <form class="needs-validation" novalidate action="<?php echo e(route('paciente.store')); ?>" method="POST" >
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('ui.agregar_persona', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <button class="btn btn-primary mt-3" type="submit">Grabar</button>
                </form>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/pais/index.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/sweetalerts/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/sweetalerts/custom-sweetalert.js')); ?>"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->

    <!--  BEGIN CUSTOM SCRIPTS FILE  -->
    <script src="<?php echo e(asset('assets/js/scrollspyNav.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/forms/bootstrap_validation/bs_validation_script.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\medicina\resources\views/paciente/create.blade.php ENDPATH**/ ?>