<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('plugins/animate/animate.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row layout-top-spacing">
        <div class="col-lg-12 layout-spacing">
            <div class="widget-content widget-content-area">
                <div class="row" style="margin-left: 3px">
                    <h3 class="mb-4">Agregar Especialidad</h3>
                </div>
                <form class="needs-validation" novalidate action="<?php echo e(route('especialidad.store')); ?>" method="POST"
                 enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="col-md-3 col-sm-6 mb-4">
                            <label for="">Descripción</label>
                            <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-6 mb-4">
                            <label for="">Limite Atención</label>
                            <input type="text" class="form-control" id="limite_atencion" name="limite_atencion" value="0" required>
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-6 mb-4">
                            <label for="">Imagen</label>
                            <input type="file" class="form-control" id="foto" name="foto" placeholder="Foto" accept="image/*">
                            <div class="valid-feedback">
                                Looks good!
                            </div>
                        </div>

                        <div class="col-md-3 col-sm-6 mb-4">
                            <label for="">Estado</label>
                            <select name="estado_id" id="estado_id" class="form-control">
                                <option value="1">ACTIVO</option>
                                <option value="2">INACTIVO</option>
                            </select>
                        </div>

                    </div>

                    <button class="btn btn-primary mt-3" type="submit">Grabar</button>
                </form>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/js/scrollspyNav.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/forms/bootstrap_validation/bs_validation_script.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\medicina\resources\views/especialidad/create.blade.php ENDPATH**/ ?>