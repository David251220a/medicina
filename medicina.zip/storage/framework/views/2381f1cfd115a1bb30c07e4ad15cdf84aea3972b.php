<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('plugins/animate/animate.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="layout-px-spacing mt-4">
        <div class="card component-card_1">
            <div class="card-body">
                <h3 class="card-title">Agendado con Exito!</h3>
                <p class="card-text">
                    Paciente: <b><?php echo e(number_format(Auth::user()->persona->documento, 0, '.', '.')); ?> -
                    <?php echo e(Auth::user()->persona->nombre); ?> <?php echo e(Auth::user()->persona->apellido); ?></b>
                    <br>
                    Especialista: <b><?php echo e($agendaConsulta->doctor_turno->doctor->especialista->descripcion); ?></b>
                    <br>
                    Doctor: <b><?php echo e($agendaConsulta->doctor_turno->doctor->persona->nombre); ?> <?php echo e($agendaConsulta->doctor_turno->doctor->persona->apellido); ?></b>
                    <br>
                    Fecha Consulta: <b><?php echo e(date('d/m/Y', strtotime($agendaConsulta->fecha_consulta))); ?></b>
                    <br>
                    Orden: <b><?php echo e($agendaConsulta->orden); ?></b>
                </p>
                <a class="btn btn-info" href="<?php echo e(route('home')); ?>">Regresar a Home!</a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/js/forms/bootstrap_validation/bs_validation_script.js')); ?>"></script>
    <script src="<?php echo e(asset('js/agenda_consulta/agendar.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\medicina\resources\views/cita_agendada.blade.php ENDPATH**/ ?>