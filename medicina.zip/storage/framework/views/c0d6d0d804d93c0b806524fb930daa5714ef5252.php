<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
<title>MED </title>

<link href="<?php echo e(asset('assets/css/loader.css')); ?>" rel="stylesheet" type="text/css" />
<script src="<?php echo e(asset('assets/js/loader.js')); ?>"></script>
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
<link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/css/plugins.css')); ?>" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/elements/alert.css')); ?>">
<!-- END GLOBAL MANDATORY STYLES -->

<link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/fontawesome.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/solid.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('fontawesome/css/solid.min.css')); ?>">
<!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<?php /**PATH C:\laragon\www\medicina\resources\views/layouts/admin/head.blade.php ENDPATH**/ ?>