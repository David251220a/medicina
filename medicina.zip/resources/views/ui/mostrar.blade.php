<div class="col-lg-2 col-md-2 col-sm-4 col-xl-2 mb-4 mt-4 px-4">
    <label for="">Mostrar</label>
    <select wire:model="pagina" class="form-control" name="" id="">
        <option value="5">5</option>
        <option value="10">10</option>
        <option value="15">15</option>
        <option value="20">20</option>
        <option value="50">50</option>
    </select>
</div>
