<div wire:ignore.self class="modal fade" id="modal" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false" aria-labelledby="modal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal">
                    {{ ($clave > 0 ? 'Editar Pais' : 'Crear Pais') }}
                </h5>
            </div>
            <div class="modal-body">

