<div class="mt-4">
    {{ $data->links() }}
</div>
