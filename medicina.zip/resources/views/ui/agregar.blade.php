<div class="px-4">
    <button class="btn btn-primary btn-rounded mb-4" data-toggle="modal" data-target="#modal"><i class="fa-solid fa-plus"></i> Agregar</button>
</div>
