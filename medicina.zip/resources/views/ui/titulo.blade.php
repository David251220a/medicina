<div class="mt-4 seperator-header">
    <h4 class="fw-bold" style="font-weight: bold">{{$titulo}}</h4>
</div>
